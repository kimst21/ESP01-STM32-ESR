/* USER CODE BEGIN Header */
/**
  *******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  *******************************************************************************
  * @attention
  *
  * 기본 설정 및 저작권 정보
  *
  *******************************************************************************
  */
// 코드 파일 정보 및 저작권 안내. STM32 프로젝트 생성 시 자동 생성됨.
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"       // STM32 하드웨어 및 소프트웨어 초기화를 위한 헤더
#include "usart.h"      // UART 통신 초기화 및 설정 함수
#include "gpio.h"       // GPIO 핀 초기화 및 상태 제어 함수

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"     // 문자열 처리 (strcpy, strcat 등)
#include "stdio.h"      // 입출력 함수 (sprintf, printf 등)
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// 사용자 정의 데이터 타입 정의 (현재 비어 있음)
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// 매크로 상수 정의 (현재 없음)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
// 사용자 정의 매크로 (현재 없음)
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
// 사용자 정의 전역 변수 선언 (현재 없음)
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void); // 시스템 클록 초기화 함수 선언
/* USER CODE BEGIN PFP */
// 사용자 정의 함수 프로토타입 선언 (현재 없음)
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 사용자 정의 함수 및 초기 코드 작성 영역
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) // 메인 함수, 프로그램 진입점
{
  /* USER CODE BEGIN 1 */
  // 사용자 정의 초기 변수 선언 및 초기화
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();  // HAL 라이브러리 초기화 (타이머, 인터럽트 등 기본 설정)

  /* USER CODE BEGIN Init */
  // 사용자 정의 초기화 코드 (필요한 경우)
  /* USER CODE END Init */

  SystemClock_Config(); // MCU 시스템 클록 구성 (CPU 속도, 타이밍 설정 등)

  /* USER CODE BEGIN SysInit */
  // 시스템 초기화 후 사용자 설정 추가 가능
  /* USER CODE END SysInit */

  MX_GPIO_Init();       // GPIO 핀 초기화 (LED 제어용 핀 등)
  MX_USART2_UART_Init(); // UART 초기화 (ESP8266과 통신용)

  /* USER CODE BEGIN 2 */
  // 사용자 정의 초기화 코드

  // UART 통신과 HTML 전송을 위한 변수 및 버퍼 설정
  uint8_t rxBuffer[512] = {0}; // UART 수신 데이터를 저장할 버퍼
  uint8_t ATisOK;             // AT 명령 응답 성공 여부 플래그
  int channel;                // 클라이언트 채널 번호 (ESP8266 다중 연결용)
  int onoff;                  // LED ON/OFF 상태 플래그
  int led = 1;                // 현재 LED 상태 (1: OFF, 0: ON)
  char ATcommand[64];         // AT 명령을 저장할 버퍼
  char ATcommandB[1024];      // HTML 페이지 기본 구조
  char ATcommandN[100];       // HTML - LED ON 상태 메시지
  char ATcommandF[100];       // HTML - LED OFF 상태 메시지
  char ATcommandT[16];        // HTML 종료 태그

  // HTML 페이지 템플릿 구성
  sprintf(ATcommandB,"<!DOCTYPE html><html>\n<head>\n\
   <title>STM32 - ESP8266</title>\n<link href=\"data:image/x-icon;base64,\
   A\" rel=\"icon\" type=\"image/x-icon\"><style>\nhtml {\
   display: inline-block; margin: 0px auto; text-align: center;}\n\
   body{margin-top: 50px;}\n.button {display: block;\n\
   width: 70px;\nbackground-color: #008000;\nborder: none;\ncolor: white;\n\
   padding: 14px 28px;\ntext-decoration: none;\nfont-size: 24px;\n\
   margin: 0px auto 36px; \nborder-radius: 5px;}\n\
   .button-on {background-color: #008000;}\n.button-on:active\
   {background-color: #008000;}\n.button-off {background-color: #808080;}\n\
   .button-off:active {background-color: #808080;}\n\
   p {font-size: 14px;color: #808080;margin-bottom: 20px;}\n\
   </style>\n</head>\n<body>\n<h1>STM32 - ESP8266</h1>");
   sprintf(ATcommandN,"<p>Light is currently on\
   </p><a class=\"button button-off\" href=\"/lightoff\">OFF</a>");
   sprintf(ATcommandF,"<p>Light is currently off\
   </p><a class=\"button button-on\" href=\"/lighton\">ON</a>");
   sprintf(ATcommandT,"</body></html>");

  // HTML 콘텐츠 길이 계산 (데이터 전송 크기 계산용)
  int countB = strlen(ATcommandB);
  int countN = strlen(ATcommandN);
  int countF = strlen(ATcommandF);
  int countT = strlen(ATcommandT);

  sprintf(ATcommand,"AT+RST\r\n");
   memset(rxBuffer,0,sizeof(rxBuffer));
   HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
   HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
   HAL_Delay(500);

   ATisOK = 0;
   while(!ATisOK){
     sprintf(ATcommand,"AT+CWMODE_CUR=2\r\n");
       memset(rxBuffer,0,sizeof(rxBuffer));
       HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
       HAL_UART_Receive (&huart2, rxBuffer, 512, 1000);
     if(strstr((char *)rxBuffer,"OK")){
       ATisOK = 1;
     }
     HAL_Delay(500);
   }

   ATisOK = 0;
   while(!ATisOK){
     sprintf(ATcommand,"AT+CWSAP_CUR=\"STM32\",\"12345678\",1,3,4,0\r\n");
       memset(rxBuffer,0,sizeof(rxBuffer));
       HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
       HAL_UART_Receive (&huart2, rxBuffer, 512, 1000);
     if(strstr((char *)rxBuffer,"OK")){
       ATisOK = 1;
     }
     HAL_Delay(500);
   }

   ATisOK = 0;
   while(!ATisOK){
     sprintf(ATcommand,"AT+CIPAP_CUR=\"192.168.51.1\"\r\n");
     memset(rxBuffer,0,sizeof(rxBuffer));
     HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
     HAL_UART_Receive (&huart2, rxBuffer, 512, 1000);
     if(strstr((char *)rxBuffer,"OK")){
       ATisOK = 1;
     }
     HAL_Delay(500);
   }

   ATisOK = 0;
   while(!ATisOK){
     sprintf(ATcommand,"AT+CIPMUX=1\r\n");
       memset(rxBuffer,0,sizeof(rxBuffer));
       HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
       HAL_UART_Receive (&huart2, rxBuffer, 512, 1000);
       if(strstr((char *)rxBuffer,"OK")){
         ATisOK = 1;
       }
       HAL_Delay(500);
   }

   ATisOK = 0;
   while(!ATisOK){
     sprintf(ATcommand,"AT+CIPSERVER=1,80\r\n");
     memset(rxBuffer,0,sizeof(rxBuffer));
     HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
     HAL_UART_Receive (&huart2, rxBuffer, 512, 1000);
     if(strstr((char *)rxBuffer,"OK")){
         ATisOK = 1;
     }
     HAL_Delay(500);
   }

  /* USER CODE END 2 */

  /* Infinite loop */
  while (1) // 메인 루프
  {

	    memset(rxBuffer,0,sizeof(rxBuffer));
	    HAL_UART_Receive (&huart2, rxBuffer, 512, 1000);
	    if(strstr((char *)rxBuffer,"+IPD,0")) channel = 0;
	    else if(strstr((char *)rxBuffer,"+IPD,1")) channel = 1;
	    else if(strstr((char *)rxBuffer,"+IPD,2")) channel = 2;
	    else if(strstr((char *)rxBuffer,"+IPD,3")) channel = 3;
	    else if(strstr((char *)rxBuffer,"+IPD,4")) channel = 4;
	    else if(strstr((char *)rxBuffer,"+IPD,5")) channel = 5;
	    else if(strstr((char *)rxBuffer,"+IPD,6")) channel = 6;
	    else if(strstr((char *)rxBuffer,"+IPD,7")) channel = 7;
	    else channel = 100;

	    if(strstr((char *)rxBuffer,"GET /lighton")) onoff = 0;
	    else if(strstr((char *)rxBuffer,"GET /lightoff")) onoff = 1;
	    else onoff = led;

	    if(channel<8 && onoff == 1)
	    {
	      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
	      led = 1;
	      sprintf(ATcommand,"AT+CIPSEND=%d,%d\r\n",channel,countB+countF+countT);
	      memset(rxBuffer,0,sizeof(rxBuffer));
	      HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
	      HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
	      if(strstr((char *)rxBuffer,">"))
	      {
	        memset(rxBuffer,0,sizeof(rxBuffer));
	          HAL_UART_Transmit(&huart2,(uint8_t *)ATcommandB,countB,1000);
	          HAL_UART_Transmit(&huart2,(uint8_t *)ATcommandF,countF,1000);
	          HAL_UART_Transmit(&huart2,(uint8_t *)ATcommandT,countT,1000);
	         HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
	      }
	      sprintf(ATcommand,"AT+CIPCLOSE=%d\r\n",channel);
	      memset(rxBuffer,0,sizeof(rxBuffer));
	      HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
	      HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
	      channel=100;
	    }
	    else if(channel<8 && onoff == 0)
	    {
	      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
	      led = 0;
	      sprintf(ATcommand,"AT+CIPSEND=%d,%d\r\n",channel,countB+countN+countT);
	      memset(rxBuffer,0,sizeof(rxBuffer));
	      HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
	      HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
	      if(strstr((char *)rxBuffer,">"))
	      {
	        memset(rxBuffer,0,sizeof(rxBuffer));
	          HAL_UART_Transmit(&huart2,(uint8_t *)ATcommandB,countB,1000);
	          HAL_UART_Transmit(&huart2,(uint8_t *)ATcommandN,countN,1000);
	          HAL_UART_Transmit(&huart2,(uint8_t *)ATcommandT,countT,1000);
	          HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
	      }
	      sprintf(ATcommand,"AT+CIPCLOSE=%d\r\n",channel);
	      memset(rxBuffer,0,sizeof(rxBuffer));
	      HAL_UART_Transmit(&huart2,(uint8_t *)ATcommand,strlen(ATcommand),1000);
	      HAL_UART_Receive (&huart2, rxBuffer, 512, 100);
	      channel=100;
  }
}
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
