/* USER CODE BEGIN Header */
/**
  *******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  *******************************************************************************
  * @attention
  *
  * STM32 프로젝트로 생성된 기본 코드. 사용자 정의 코드는 BEGIN/END 섹션에 작성.
  *
  *******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"       // STM32 하드웨어 및 소프트웨어 초기화를 위한 헤더
#include "usart.h"      // UART 통신 초기화 및 설정 함수
#include "gpio.h"       // GPIO 핀 초기화 및 상태 제어 함수

/* Private includes ----------------------------------------------------------*/
#include "string.h"     // 문자열 처리 (strcpy, strcat 등)
#include "stdio.h"      // 입출력 함수 (sprintf, printf 등)

/* Private variables ---------------------------------------------------------*/
uint8_t rxBuffer[512] = {0}; // UART 통신에서 수신된 데이터를 저장하는 버퍼입니다. 최대 512바이트 데이터를 저장할 수 있습니다.
uint8_t ATisOK;             // AT 명령 응답 성공 여부를 나타내는 플래그 변수입니다.
int channel;                // 클라이언트 채널 번호 (ESP8266 다중 연결용)입니다.
int onoff;                  // LED ON/OFF 상태를 나타내는 플래그 변수입니다.
int led = 1;                // 현재 LED 상태를 저장합니다. (1: OFF, 0: ON)
char ATcommand[64];         // AT 명령을 저장하는 버퍼입니다.
char ATcommandB[1024];      // HTML 페이지 기본 구조를 저장하는 버퍼입니다.
char ATcommandN[100];       // LED ON 상태를 나타내는 HTML 메시지를 저장하는 버퍼입니다.
char ATcommandF[100];       // LED OFF 상태를 나타내는 HTML 메시지를 저장하는 버퍼입니다.
char ATcommandT[16];        // HTML 종료 태그를 저장하는 버퍼입니다.

/* Function prototypes -------------------------------------------------------*/
void SystemClock_Config(void); // 시스템 클록 초기화를 위한 함수 선언입니다.

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {
  // 1. STM32 기본 초기화
  HAL_Init();                    // HAL 라이브러리 초기화. MCU의 기본 설정 및 인터럽트 우선순위를 구성합니다.
  SystemClock_Config();          // 시스템 클록 설정. CPU 클록 및 주변 장치 클록을 초기화합니다.
  MX_GPIO_Init();                // GPIO 핀 초기화. LED 제어용 핀을 활성화합니다.
  MX_USART2_UART_Init();         // UART2 초기화. ESP8266과의 데이터 송수신을 설정합니다.

  // 2. HTML 페이지 템플릿 생성
  sprintf(ATcommandB, "<!DOCTYPE html><html><head><title>STM32 - ESP8266</title><link href=\"data:image/x-icon;base64,A\" rel=\"icon\" type=\"image/x-icon\"><style>html {display: inline-block; margin: 0px auto; text-align: center;} body{margin-top: 50px;} .button {display: block; width: 70px; background-color: #008000; border: none; color: white; padding: 14px 28px; text-decoration: none; font-size: 24px; margin: 0px auto 36px; border-radius: 5px;} .button-on {background-color: #008000;} .button-on:active {background-color: #008000;} .button-off {background-color: #808080;} .button-off:active {background-color: #808080;} p {font-size: 14px;color: #808080;margin-bottom: 20px;}</style></head><body><h1>STM32 - ESP8266</h1>");
  sprintf(ATcommandN, "<p>Light is currently on</p><a class=\"button button-off\" href=\"/lightoff\">OFF</a>"); // LED가 켜져 있을 때 표시할 메시지
  sprintf(ATcommandF, "<p>Light is currently off</p><a class=\"button button-on\" href=\"/lighton\">ON</a>"); // LED가 꺼져 있을 때 표시할 메시지
  sprintf(ATcommandT, "</body></html>"); // HTML 종료 태그

  // 3. HTML 콘텐츠 길이 계산
  int countB = strlen(ATcommandB); // HTML 기본 구조 길이 계산
  int countN = strlen(ATcommandN); // LED ON 메시지 길이 계산
  int countF = strlen(ATcommandF); // LED OFF 메시지 길이 계산
  int countT = strlen(ATcommandT); // HTML 종료 태그 길이 계산

  // 4. ESP8266 초기화 및 설정
  sprintf(ATcommand, "AT+RST\r\n"); // ESP8266 초기화를 위한 AT 명령어
  HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000); // 초기화 명령 전송
  HAL_Delay(500); // 초기화 후 안정화를 위해 지연

  // AP 모드 설정
  do {
    sprintf(ATcommand, "AT+CWMODE_CUR=2\r\n"); // AP 모드 설정 명령어
    HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000); // 명령어 전송
    HAL_UART_Receive(&huart2, rxBuffer, 512, 1000); // 응답 수신
  } while (!strstr((char *)rxBuffer, "OK")); // 설정 성공 시 루프 탈출

  // SSID 및 비밀번호 설정
  do {
    sprintf(ATcommand, "AT+CWSAP_CUR=\"STM32\",\"12345678\",1,3,4,0\r\n"); // AP 정보 설정
    HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000);
    HAL_UART_Receive(&huart2, rxBuffer, 512, 1000);
  } while (!strstr((char *)rxBuffer, "OK"));

  // 다중 연결 활성화
  do {
    sprintf(ATcommand, "AT+CIPMUX=1\r\n"); // 다중 연결 활성화 명령
    HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000);
    HAL_UART_Receive(&huart2, rxBuffer, 512, 1000);
  } while (!strstr((char *)rxBuffer, "OK"));

  // HTTP 서버 시작
  do {
    sprintf(ATcommand, "AT+CIPSERVER=1,80\r\n"); // HTTP 서버 시작 명령어
    HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000);
    HAL_UART_Receive(&huart2, rxBuffer, 512, 1000);
  } while (!strstr((char *)rxBuffer, "OK"));

  // 5. 메인 루프 (클라이언트 요청 처리)
  while (1) {
    memset(rxBuffer, 0, sizeof(rxBuffer)); // 수신 버퍼 초기화
    HAL_UART_Receive(&huart2, rxBuffer, 512, 1000); // 클라이언트 요청 수신

    // 클라이언트 채널 번호 파싱
    if (strstr((char *)rxBuffer, "+IPD,0")) channel = 0;
    else if (strstr((char *)rxBuffer, "+IPD,1")) channel = 1;
    else channel = 100; // 유효하지 않은 경우

    // HTTP 요청 분석
    if (strstr((char *)rxBuffer, "GET /lighton")) onoff = 0; // LED ON 요청
    else if (strstr((char *)rxBuffer, "GET /lightoff")) onoff = 1; // LED OFF 요청
    else onoff = led; // 현재 LED 상태 유지

    // 요청 처리 및 LED 제어
    if (channel < 8) {
      if (onoff == 1) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); // LED 켜기
        led = 1; // LED 상태 저장
        sprintf(ATcommand, "AT+CIPSEND=%d,%d\r\n", channel, countB + countF + countT); // HTML 콘텐츠 길이 계산
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000);
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommandB, countB, 1000); // HTML 본문 전송
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommandF, countF, 1000); // LED OFF 메시지 전송
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommandT, countT, 1000); // HTML 종료 태그 전송
      } else {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET); // LED 끄기
        led = 0; // LED 상태 저장
        sprintf(ATcommand, "AT+CIPSEND=%d,%d\r\n", channel, countB + countN + countT); // HTML 콘텐츠 길이 계산
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000);
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommandB, countB, 1000); // HTML 본문 전송
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommandN, countN, 1000); // LED ON 메시지 전송
        HAL_UART_Transmit(&huart2, (uint8_t *)ATcommandT, countT, 1000); // HTML 종료 태그 전송
      }
      sprintf(ATcommand, "AT+CIPCLOSE=%d\r\n", channel); // 클라이언트 연결 종료 명령어
      HAL_UART_Transmit(&huart2, (uint8_t *)ATcommand, strlen(ATcommand), 1000);
    }
  }
}



/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
